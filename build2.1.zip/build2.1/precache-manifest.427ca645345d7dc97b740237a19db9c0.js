self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "03252289cb5f8a8cfaa4d08510982e74",
    "url": "/index.html"
  },
  {
    "revision": "7e97ea1d64139a2e3069",
    "url": "/static/css/main.09d43332.chunk.css"
  },
  {
    "revision": "09b257152efe31750122",
    "url": "/static/js/2.cebdf947.chunk.js"
  },
  {
    "revision": "8d190e2d02f8e768921a63f56a741895",
    "url": "/static/js/2.cebdf947.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7e97ea1d64139a2e3069",
    "url": "/static/js/main.ebb57b0d.chunk.js"
  },
  {
    "revision": "4b6c0fe0c6f7478ae58c",
    "url": "/static/js/runtime-main.c94b602f.js"
  },
  {
    "revision": "2775e089819117fcb32015448fa38c24",
    "url": "/static/media/BUFFO_Updated-1.2775e089.jpg"
  },
  {
    "revision": "02998f37afc36e7021ce9490fe8851db",
    "url": "/static/media/Canteen-Blue-Jays-Promo-5889_JPG.02998f37.jpg"
  },
  {
    "revision": "95efc86bee0cdc80294717b3d1c46ca0",
    "url": "/static/media/Canteen-Blue-Jays-Promo-5971-2_JPG.95efc86b.jpg"
  },
  {
    "revision": "ff895dde1054f531cf63171e30bb4e91",
    "url": "/static/media/Chrome-Browser.ff895dde.gif"
  },
  {
    "revision": "4040efe2b73b764c39ca81c9db694e3a",
    "url": "/static/media/Eblast-HolidayParty-October2019Artboard 1.4040efe2.jpg"
  },
  {
    "revision": "f108a1bc46433e77715270f889e727af",
    "url": "/static/media/IMG_1378.f108a1bc.jpg"
  },
  {
    "revision": "538cdb2a35fa80d2b87101d11039a7d2",
    "url": "/static/media/IMG_4598.538cdb2a.jpg"
  },
  {
    "revision": "2efd3de5f7a5db5324dc9a9f067347ae",
    "url": "/static/media/IMG_4843.2efd3de5.jpg"
  },
  {
    "revision": "5959a17885bd571b71b882a23db78b0e",
    "url": "/static/media/IMG_5546.5959a178.jpg"
  },
  {
    "revision": "d390b77d5b2527a0fa40d5566e658953",
    "url": "/static/media/IMG_5554.d390b77d.jpg"
  },
  {
    "revision": "161eeef9227b719c298370742567c0d5",
    "url": "/static/media/IMG_5560.161eeef9.jpg"
  },
  {
    "revision": "50ef62caebee3b73fa1399c91b9f5912",
    "url": "/static/media/IMG_5566.50ef62ca.jpg"
  },
  {
    "revision": "760b580f5dcbc592c86cdf92bc5a3cfd",
    "url": "/static/media/IMG_5581.760b580f.jpg"
  },
  {
    "revision": "d8bfe28030c5c18c6f69cc16eaf4b1dd",
    "url": "/static/media/IMG_5589.d8bfe280.jpg"
  },
  {
    "revision": "17592d34dacba1a039618491f3f3064e",
    "url": "/static/media/LF-Vertical-ANGLED-LEFT.17592d34.jpg"
  },
  {
    "revision": "1edea82a317058013a202b87cd90a499",
    "url": "/static/media/LODP0063.1edea82a.jpg"
  },
  {
    "revision": "3821400af577699b9ad7eab3b8e7e4e6",
    "url": "/static/media/LODP0072.3821400a.jpg"
  },
  {
    "revision": "de9f6cc43a30b4752e39fa26f22ea488",
    "url": "/static/media/LODP0079.de9f6cc4.jpg"
  },
  {
    "revision": "ae9d2f4e245fb52f613743e710b4d943",
    "url": "/static/media/LODP0302.ae9d2f4e.jpg"
  },
  {
    "revision": "d816761eba547537091742d1f9740db9",
    "url": "/static/media/Little_Foot_1_Page_07.d816761e.jpg"
  },
  {
    "revision": "9b96c01b6aed4eb116e8d8de4be42980",
    "url": "/static/media/Little_Foot_1_Page_10.9b96c01b.jpg"
  },
  {
    "revision": "d72d8c6b5f2cced0779e6692a1a67196",
    "url": "/static/media/Little_Foot_1_Page_11.d72d8c6b.jpg"
  },
  {
    "revision": "bf45bef1d292e7196575f39cf6aac0a1",
    "url": "/static/media/SOUVENIRSTD-LIGHT.bf45bef1.OTF"
  },
  {
    "revision": "202032391b9b94bf06664d0e195cebcb",
    "url": "/static/media/SOUVENIRSTD-MEDIUM.20203239.OTF"
  },
  {
    "revision": "a3bd9e4d682b9036414daa65ea5c7d8d",
    "url": "/static/media/Seakura-SOCIAL_1.a3bd9e4d.jpg"
  },
  {
    "revision": "2129c1b4c0191ad386e40db55c9f302d",
    "url": "/static/media/Seakura-logo.2129c1b4.jpg"
  },
  {
    "revision": "f5bc20c120dc7225c36d462d1459f30f",
    "url": "/static/media/Valentines-Eblast.f5bc20c1.jpg"
  },
  {
    "revision": "290bbbac9b4ca41aec9a6d82061c3114",
    "url": "/static/media/babel-businesscard-mock.290bbbac.jpg"
  },
  {
    "revision": "5c7d2bbc7680136b3f3a6f630bd7755d",
    "url": "/static/media/babel-friends-family-8543.5c7d2bbc.jpg"
  },
  {
    "revision": "1b906079762f645b9aee5ef3ea4b3e16",
    "url": "/static/media/babel-friends-family-9031.1b906079.jpg"
  },
  {
    "revision": "471041c7902393be8dbe3091fd36ea6b",
    "url": "/static/media/babel-tasting-4061.471041c7.jpg"
  },
  {
    "revision": "ac45cad76e8835fb9a6906e6b3e3e83d",
    "url": "/static/media/bannock-redesign_Page_1.ac45cad7.jpg"
  },
  {
    "revision": "10e0b51232c76055867d75044aede500",
    "url": "/static/media/bannock-redesign_Page_2.10e0b512.jpg"
  },
  {
    "revision": "c22b32f833c1ba0c2c74834deec88e71",
    "url": "/static/media/bannock-redesign_Page_3.c22b32f8.jpg"
  },
  {
    "revision": "9623d8a7921aef6c95e34c347626dc0e",
    "url": "/static/media/bannock-redesign_Page_4.9623d8a7.jpg"
  },
  {
    "revision": "8cd29485418228e5cf60cdba42a13623",
    "url": "/static/media/buffo-menu1.8cd29485.jpg"
  },
  {
    "revision": "de9b7832fff710f460451021c77de030",
    "url": "/static/media/buffo-menu2.de9b7832.jpg"
  },
  {
    "revision": "a92bc3e663c7657acd5cb7b819e80a63",
    "url": "/static/media/buffo-menu3.a92bc3e6.jpg"
  },
  {
    "revision": "b753e7bcd9d3a9ec4e6a386067a848f9",
    "url": "/static/media/buffo.b753e7bc.jpg"
  },
  {
    "revision": "7e59cf627fc3e33bcd35e9780f055096",
    "url": "/static/media/canteen-live-eat-1618.7e59cf62.jpg"
  },
  {
    "revision": "e165e7a192a19e46c8ceb7c4a091cf3f",
    "url": "/static/media/canteen-redesign.e165e7a1.jpg"
  },
  {
    "revision": "2725fe171266618fae93847ce18df7a3",
    "url": "/static/media/canteen-redesign_Page_1.2725fe17.jpg"
  },
  {
    "revision": "544d35d31ec44911cb147b1217be008a",
    "url": "/static/media/canteengif2.544d35d3.gif"
  },
  {
    "revision": "532773c8b474d81ff08ca91997f7f583",
    "url": "/static/media/cyborg_web.532773c8.gif"
  },
  {
    "revision": "8984a8551144aeddb19ba27ee4035414",
    "url": "/static/media/ezgif-2-258dd2291053.8984a855.gif"
  },
  {
    "revision": "50515ebe3795b9004a82c46ae8e1535b",
    "url": "/static/media/littlefoot-pixelphone.50515ebe.gif"
  },
  {
    "revision": "e659cb69ce35469284525331e0c4da1d",
    "url": "/static/media/p1.e659cb69.jpg"
  },
  {
    "revision": "c5beb4e4dd807a9c942fc64adc1128b7",
    "url": "/static/media/p2.c5beb4e4.jpg"
  },
  {
    "revision": "441d8a12e1d5cce0f2f39e7eac6b28cd",
    "url": "/static/media/p3.441d8a12.jpg"
  },
  {
    "revision": "6791c8805405ece43d3fffc93eb42a2f",
    "url": "/static/media/p4.6791c880.jpg"
  },
  {
    "revision": "2616d281f9cb5fafb3ff889d0afa8cbd",
    "url": "/static/media/seakura_grid.2616d281.png"
  },
  {
    "revision": "df48ad00f5b4801adf3c65f41dc1a94a",
    "url": "/static/media/youvegotmail.df48ad00.jpg"
  }
]);